import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Home } from "./pages/Home.jsx";
import { Contacto } from "./pages/Contacto.jsx";
import { NotFoundPage } from "./pages/NotFoundPage.jsx";
import { WatchVideos } from "./pages/WatchVideos.jsx";
import { Inscripcion } from "./pages/Inscripcion.jsx";
import { Ciclo } from "./pages/especialidades-pages/Ciclo-basico";
import { Programacion } from "./pages/especialidades-pages/Programacion";
import { Informatica } from "./pages/especialidades-pages/Informatica";
import { Mmo } from "./pages/especialidades-pages/Mmo";

import "./index-darkmode.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/contacto" element={<Contacto />} />
        <Route path="/inscripcion" element={<Inscripcion />} />
        <Route path="/ciclo-basico" element={<Ciclo />} />
        <Route path="/Watch" element={<WatchVideos />} />
        <Route path="/especialidad/programacion" element={<Programacion />} />
        <Route path="/especialidad/informatica" element={<Informatica />} />
        <Route path="/especialidad/maestro-mayor-de-obra" element={<Mmo />} />
        <Route path="/*" element={<NotFoundPage />} />
      </Routes>
    </Router>
  </React.StrictMode>
);
