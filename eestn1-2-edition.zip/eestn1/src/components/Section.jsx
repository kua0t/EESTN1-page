import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import logo from "../assets/slider-img-ico/logo.png";
import banner0 from "../assets/slider-img-ico/banner.png";
import banner1 from "../assets/slider-img-ico/banner-1.png";
import banner2 from "../assets/slider-img-ico/banner-2.png";
import banner3 from "../assets/slider-img-ico/banner-3.png";
import comienzoImg from "../assets/history-ico/comienzo.png";
import metaImg from "../assets/history-ico/meta.png";
import desarrolloImg from "../assets/history-ico/desafios.png";
import leyImg from "../assets/history-ico/ley.png";
import finishImg from "../assets/history-ico/finish.png";
import videoImg from "../assets/history-ico/historia.png";

export const Section = () => {
  useEffect(() => {
    const banners = document.querySelectorAll(".banner");
    let currentIndex = 0;

    function timeBanner() {
      currentIndex = (currentIndex + 1) % banners.length;
      showBanner(currentIndex);
    }

    function nextBanner() {
      currentIndex = (currentIndex + 1) % banners.length;
      showBanner(currentIndex);
    }

    function prevBanner() {
      currentIndex = (currentIndex - 1 + banners.length) % banners.length;
      showBanner(currentIndex);
    }

    function showBanner(index) {
      banners.forEach((banner) => {
        banner.style.display = "none";
      });
      banners[index].style.display = "block";
    }

    document
      .querySelector(".prev-button")
      .addEventListener("click", prevBanner);
    document
      .querySelector(".next-button")
      .addEventListener("click", nextBanner);

    // Mostrar el primer banner al cargar la página
    showBanner(currentIndex);

    // Limpiar event listeners al desmontar el componente
    return () => {
      const prevButton = document.querySelector(".prev-button");
      const nextButton = document.querySelector(".next-button");

      if (prevButton && nextButton) {
        document
          .querySelector(".prev-button")
          .removeEventListener("click", prevBanner);
        document
          .querySelector(".next-button")
          .removeEventListener("click", nextBanner);
      }
    };
  }, []);

  return (
    <>
      <section>
        <div className="banner-container">
          <button className="prev-button"></button>
          <div className="banner banner-0">
            <img src={banner0} alt="banner-0" className="banner-img" />
            <div className="banner-text banner-text-0">
              <img src={logo} alt="logo-eestn1" className="banner-logo" />
              <p>Escuela de Educacion Secundaria Tecnica N°1 </p>
              <p>"Manuel Belgrano"</p>
              <p>Tres de Febrero</p>
            </div>
          </div>
          <div className="banner banner-1">
            <img src={banner1} alt="banner-1" className="banner-img" />
            <div className="banner-text banner-text-1">
              <img src={logo} alt="logo-eestn1" className="banner-logo" />
              <p>Especialidad: Programacion</p>
            </div>
          </div>
          <div className="banner banner-2">
            <img src={banner2} alt="banner-2" className="banner-img" />
            <div className="banner-text banner-text-2">
              <img src={logo} alt="logo-eestn1" className="banner-logo" />
              <p>Especialidad: Maestro Mayor de Obras</p>
            </div>
          </div>
          <div className="banner banner-3">
            <img src={banner3} alt="banner-3" className="banner-img" />
            <div className="banner-text banner-text-3">
              <img src={logo} alt="logo-eestn1" className="banner-logo" />
              <p>Especialidad: Informatica</p>
            </div>
          </div>
          <button className="next-button"></button>
        </div>
        <div className="history-container" name="section">
          <h2>
            Breve historia de la E.E.S.T. Nº1 "Manuel Belgrano", Distrito Tres
            de Febrero.
          </h2>
          <div className="history-grid">
            <fieldset className="first-box fieldGrid">
              <legend className="legendGrid">
                <img src={videoImg} alt="" />
              </legend>
              <h5>Videos</h5>
              <p className="p-text">Recorrido de la escuela (video)</p>
              <Link to="/Watch#Recorrido-Escuela">
                <button>Presione Aqui para ver</button>
              </Link>
              <p className="p-text">La historia de la tecnica en video</p>
              <Link to="/Watch#Historia-Video">
                <button>Presione Aqui para ver</button>
              </Link>
            </fieldset>
            <fieldset className="fieldGrid">
              <legend className="legendGrid">
                <img src={comienzoImg} alt="comienzo-ico" />
              </legend>
              <h5>El Comienzo</h5>
              <p>
                La escuela tuvo sus comienzos en 1936 como la Escuela
                Profesional de Artes y Oficios en Sáenz Peña, Tres de Febrero.
                En 1978, se expandió como institución de educación técnica y
                agraria con el plan Polivalente.
              </p>
            </fieldset>
            <fieldset className="fieldGrid">
              <legend className="legendGrid">
                <img src={metaImg} alt="comienzo-ico" />
              </legend>
              <h5>Establecimiento</h5>
              <p>
                La escuela técnica se establece en 1981, compartiendo edificio
                con la Escuela Primaria Nº 19 "Antártida Argentina". En 1988, se
                coloca la piedra fundamental en su ubicación actual en Nicaragua
                3516, Santos Lugares.
              </p>
            </fieldset>
            <fieldset className="fieldGrid">
              <legend className="legendGrid">
                <img src={desarrolloImg} alt="comienzo-ico" />
              </legend>
              <h5>Desarrollo</h5>
              <p>
                Durante los años que van desde 1990, se desarrolla el plan dual
                hasta el año 1996, en el cual se cierra para dar paso a la
                apertura de la especialidad "Bienes y Servicios", incorporando
                la orientación de Informática en el año 1997.
              </p>
            </fieldset>
            <fieldset className="fieldGrid">
              <legend className="legendGrid">
                <img src={leyImg} alt="comienzo-ico" />
              </legend>
              <h5>Ley de Educación</h5>
              <p>
                En el año de la implementación de la Ley Federal de Educación,
                se establecen articulaciones con las escuelas primarias 19 y 14,
                manteniendo el tercer ciclo exigido por ley y añadiendo un ciclo
                de 3 años con dos especialidades: Maestro Mayor de Obra e
                Informática.
              </p>
            </fieldset>
            <fieldset className="fieldGrid">
              <legend className="legendGrid">
                <img src={finishImg} alt="comienzo-ico" />
              </legend>
              <h5>Llegando a la meta</h5>
              <p>
                En 2008, la comunidad educativa se trasladó al nuevo edificio.
                En 2012, debido a la demanda, se añadió la especialidad de
                Técnico en Programación. Hoy en día, la escuela ofrece
                especialidades en Informática Profesional y Personal,
                Programación y Maestro Mayor de Obra, impulsadas por la Ley de
                Educación Técnica y los proyectos de construcción en curso.
              </p>
            </fieldset>
          </div>
        </div>
      </section>
    </>
  );
};
