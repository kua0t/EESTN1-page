import React, { useState } from "react";
import { Link, Element } from "react-scroll";
import { Link as RouterLink } from "react-router-dom";
import logo from "../assets/logo.png";
import sol from "../assets/sol.png";
import luna from "../assets/luna.png";
import { Home } from "../pages/Home";
import { Contacto } from "../pages/Contacto";

export const Header = () => {
  const [isDayMode, setIsDayMode] = useState(true);

  const toggleMode = () => {
    setIsDayMode((prevMode) => !prevMode);
  };

  return (
    <header>
      <div className="title">
        <img src={logo} alt="Logo" />
        <h1>EESTN1</h1>
      </div>
      <nav>
        <ul>
          <li>
            <RouterLink to="/">
              <p className="nav-text">INICIO</p>
            </RouterLink>
          </li>
          <li>
            <Link to="section" smooth={true} duration={500} offset={-105}>
              <p className="nav-text">HISTORIA</p>
            </Link>
          </li>
          <li>
            <RouterLink to="/especialidad">
              <p href="" className="nav-text">
                ESPECIALIDADES
              </p>
            </RouterLink>
          </li>
          <li>
            <RouterLink to="/contacto">
              <p className="nav-text">CONTACTO</p>
            </RouterLink>
          </li>
          <li>
            <RouterLink to="/inscripcion">
              <p className="nav-text">INCRIPCION</p>
            </RouterLink>
          </li>
          <li>
            <RouterLink
              to="https://eestn1tfeb.blogspot.com/"
              target="_blank"
              rel="noopener noreferrer"
            >
              <p className="nav-text">BLOG</p>
            </RouterLink>
          </li>
        </ul>
        <button onClick={toggleMode}>
          <img src={isDayMode ? sol : luna} alt="" />
        </button>
      </nav>
    </header>
  );
};
