import React, { useEffect } from "react";

export const InscripcionSect = () => {
  const descargarPDF = (nombreArchivo, rutaArchivo) => {
    const linkDescarga = document.createElement("a");
    linkDescarga.href = rutaArchivo;
    linkDescarga.download = nombreArchivo;
    linkDescarga.classList.add("temporal-download-link");

    document.body.appendChild(linkDescarga);
    linkDescarga.click();

    linkDescarga.addEventListener("click", () => {
      document.body.removeChild(linkDescarga);
    });
  };

  return (
    <div className="inscripciones-container">
      <h1>Pre-Inscripción a la técnica</h1>
      <div className="field-container">
        <fieldset className="fieldFlex">
          <div className="fieldContent">
            <h5>Completar el Formulario</h5>
            <p>
              Apretando el botón que se posiciona debajo se le redireccionará al
              formulario de pre/inscripción
            </p>
          </div>
          <div className="legend-container">
            <span className="legend">
              <a
                href="https://docs.google.com/forms/d/e/1FAIpQLSc38F7wDI1nilrWBnxxQ0XL_4WhHDqd8FOPt2_hXijZX30Dcg/closedform"
                target="_blank"
                rel="noreferrer"
              >
                <button className="inscripcion-btn form-btn">
                  Formulario de Pre-Inscripción Online
                </button>
              </a>
            </span>
          </div>
        </fieldset>
        <fieldset className="fieldFlex">
          <div className="fieldContent">
            <h5>Descarga del Formulario</h5>
            <p>
              Apretando el botón que esta debajo se le descargará
              automáticamente el formulario de inscripción
            </p>
          </div>
          <div className="legend-container">
            <span className="legend">
              <button
                className="inscripcion-btn download-btn1"
                onClick={() =>
                  descargarPDF(
                    "PLANILLA INSCRIPCION -SECUNDARIA actualizada.pdf",
                    "/ruta/a/PLANILLA INSCRIPCION -SECUNDARIA actualizada.pdf"
                  )
                }
              >
                Descargar formulario de inscripción
              </button>
            </span>
          </div>
        </fieldset>
        <fieldset className="fieldFlex">
          <div className="fieldContent">
            <h5>Descarga del Formulario de autorización de uso de imagen</h5>
            <p>
              Presionando el botón que esta debajo se le descargará
              automáticamente el formulario de autorización de uso de imagen
            </p>
          </div>
          <div className="legend-container">
            <span className="legend">
              <button
                className="inscripcion-btn download-btn1"
                onClick={() =>
                  descargarPDF(
                    "Autorizacion de uso de imagen ESTUDIANTES.pdf",
                    "/ruta/a/Autorizacion de uso de imagen ESTUDIANTES.pdf"
                  )
                }
              >
                Descargar formulario de autorización de uso de imagen
              </button>
            </span>
          </div>
        </fieldset>
      </div>
    </div>
  );
};
