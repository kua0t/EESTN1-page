import React from "react";
import ico1 from "../assets/contacto-ico/phone-ico.jpg";
import ico2 from "../assets/contacto-ico/email-ico.jpg";
import ico3 from "../assets/contacto-ico/localizacion.png";
import ico4 from "../assets/contacto-ico/operador.png";

export const IframeSect = () => {
  return (
    <>
      <div className="contact-container">
        <div className="iframe-container">
          <h1>Ubicacion de la Tecnica</h1>
          <div className="iframe">iframe</div>
        </div>
        <div className="informacion">
          <h1>Informacion</h1>
          <div className="telefono">
            <span>
              <img src={ico1} alt="" className="info-ico" />
              <h2>Telefonos:</h2>
            </span>
            <p>4712 - 6983</p>
            <p>4757 - 2546</p>
          </div>
          <div className="email">
            <span>
              <img src={ico2} alt="" className="info-ico" />
              <h2>Correo:</h2>
            </span>
            <p>eest1tresdefebrero@abc.gob.ar</p>
          </div>
          <div className="direccion">
            <span>
              <img src={ico3} alt="" className="info-ico" />
              <h2>Direccion:</h2>
            </span>
            <p>Nicaragua 3516, Santos Lugares, Buenos Aires, Argentina</p>
          </div>
          <div className="inscribirse">
            :
            <span>
              <img src={ico4} alt="" className="info-ico" />
              <h2>Información y Asesoramiento (inscripciones):</h2>
            </span>
            <p>oficinadealumnost1tfeb@gmail.com</p>
          </div>
        </div>
      </div>
    </>
  );
};
