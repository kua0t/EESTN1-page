import React from "react";

export const WatchVideos = () => {
  return <div>WatchVideos</div>;
};
