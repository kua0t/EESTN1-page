import React from "react";

export const Programacion = () => {
  return <div>Programacion</div>;
};
