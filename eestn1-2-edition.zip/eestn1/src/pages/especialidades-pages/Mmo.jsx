import React from "react";

export const Mmo = () => {
  return <div>Mmo</div>;
};
