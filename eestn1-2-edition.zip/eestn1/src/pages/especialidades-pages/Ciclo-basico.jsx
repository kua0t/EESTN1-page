import React from "react";

export const Ciclo = () => {
  return <div>Ciclo-basico</div>;
};
