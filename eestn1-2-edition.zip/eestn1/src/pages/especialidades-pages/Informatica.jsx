import React from "react";

export const Informatica = () => {
  return <div>Informatica</div>;
};
