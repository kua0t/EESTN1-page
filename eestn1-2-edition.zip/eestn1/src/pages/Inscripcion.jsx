import React from "react";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { InscripcionSect } from "../components/InscripcionSect";

export const Inscripcion = () => {
  return (
    <>
      <Header />
      <InscripcionSect />
      <Footer />
    </>
  );
};
