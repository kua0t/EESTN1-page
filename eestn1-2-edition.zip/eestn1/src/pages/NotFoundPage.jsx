import React from "react";

export const NotFoundPage = () => {
  return (
    <div className="notFound">
      <h1>ERROR 404</h1>
      <p>Not found page</p>
    </div>
  );
};
