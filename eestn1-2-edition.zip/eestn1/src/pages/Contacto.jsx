import React from "react";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { IframeSect } from "../components/IframeSect";

export const Contacto = () => {
  return (
    <>
      <Header />
      <IframeSect />
      <Footer />
    </>
  );
};
