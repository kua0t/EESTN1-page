import React from 'react'
import logo from "../assets/logo.png";
import telefono from "../assets/telefono.png"
import ubicacion from "../assets/ubicacion.png"
import carrera from "../assets/sombrero-de-graduacion.png"

export const Footer = () => {
  return (
    <footer>
        <img src={logo} alt="" />
        <div className='materias'>
            <div className='header-foot'>
                <p>Carreras</p>
                <img src={carrera} alt="" />
            </div>
            <a  href="">Ciclo basico</a>
            <a  href="">Informatica</a>
            <a  href="">Programacion</a>
            <a  href="">MMO</a>
        </div>
        <div className='telefonos'>
            <div className='header-foot'>
                <p>Telefonos</p>
                <img src={telefono} alt="" />
            </div>
            <p>4712 - 6983</p>
            <p>4757 - 2546</p>
        </div>
        <div className='info'>
            <div className='header-foot'>
                <p>Ubicacion</p>
                <img src={ubicacion} alt="" />
            </div>
            <p>Nicaragua 3516, Santos Lugares</p>
            <p>Buenos Aires Argentina</p>
        </div>
    </footer>
  )
}
