import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import logo from "../assets/logo.png";
import sol from "../assets/sol.png";
import luna from "../assets/luna.png";

export const Header = () => {
  const [isDayMode, setIsDayMode] = useState(true);

  const toggleMode = () => {
    setIsDayMode(prevMode => !prevMode);
  };

  return (
    <header>
      <div className='title'>
        <img src={logo} alt="Logo" />
        <h1>EESTN1</h1>
      </div>
      <nav>
        <ul>
          <li>
            <Link to="/">INICIO</Link>
          </li>
          <li>
            <Link to="/historia">HISTORIA</Link>
          </li>
          <li>
            <Link to="/especialidades">ESPECIALIDADES</Link>
          </li>
          <li>
            <Link to="/contacto">CONTACTO</Link>
          </li>
          <li>
            <Link to="/inscripcion">INSCRIPCION</Link>
          </li>
          <li>
            <Link to="/blog">BLOG</Link>
          </li>
        </ul>
        <button onClick={toggleMode}>
          <img src={isDayMode ? sol : luna} alt="" />
        </button>
      </nav>
    </header>
  );
};
