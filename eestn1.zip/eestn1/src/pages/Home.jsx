import React from 'react'
import logo from "../assets/logo.png";
import {Header} from '../components/Header.jsx'
import {Footer} from '../components/Footer.jsx'
import image1 from "../assets/CICLO-BASICO.png"

export const Home = () => {
  return (
    <>
    <Header />
    <div className='banner'>
        <div className='banner-inside'>
            <img src={logo} alt="" />
            <div className='banner-text'>
                <p>ESCUELA DE EDUCACIÓN SECUNDARIA TÉCNICA Nº1</p>
                <p>"MANUEL BELGRANO"</p>
                <p>TRES DE FEBRERO</p>
            </div>
        </div> 
    </div>
    <div className='especialidades'>
        <p>Especialidades</p>
        <div className='slider'>
          <img src={image1} alt="ciclo basico" />
          <div className='botones'>
            <button>Anterior</button>
            <button>Siguiente</button>
          </div>
        </div>
    </div>
    <Footer />
    </>
  )
}
